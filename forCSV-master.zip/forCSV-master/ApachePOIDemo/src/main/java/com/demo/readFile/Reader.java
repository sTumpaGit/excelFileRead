package com.demo.readFile;

import java.io.File;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.stereotype.Service;

@Service
public class Reader {

    public static final String xlsFilePath = "src\\main\\resources\\Data\\xlsDemo.xls";
    public static final String xlsxFilePath = "src\\main\\resources\\Data\\xlsxDemo.xlsx";

    public boolean readerFile(String data) throws IOException {

	try {

	    Workbook workbook = WorkbookFactory.create(new File(xlsFilePath));

	    DataFormatter formatter = new DataFormatter();
	    Sheet sheet = workbook.getSheetAt(0);

	    boolean flag = false;
	    for (Row row : sheet) {
		Cell cell = row.getCell(2); // provide the cell no where the mobile numbers are kept
		String cellValue = formatter.formatCellValue(cell);
		if (cellValue.equals(data)) {
		    System.out.println("Yes Present");
		    return true;
		}
	    }
	    workbook.close();

	    System.out.println("Not Present");
	} catch (Exception e) {
	    e.printStackTrace();
	}
	return false;
    }
}
