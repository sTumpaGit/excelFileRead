package com.demo.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.demo.readFile.Reader;

@RestController
@RequestMapping("/reader")
public class Controller {

    @Autowired
    Reader reader;

    @GetMapping(value = "/checkFile")
    public boolean callReader(@RequestParam String data) throws IOException {
	return reader.readerFile(data);
    }
}

//http://localhost:9901/reader/checkFile?data=8998