package com.opencsvproject.controller;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;

@RestController
@RequestMapping(value = "/opencsv")
public class CsvController {

    List<String[]> list = new ArrayList<>();

    public void createData() { // String[] header = { "id", "name", "author" };
	// list.add(header);
	list.add(new String[] { "1", "Chaya", "Prakasani", "9876432" });
	list.add(new String[] { "2", "Maya", "akasani", "67237838" });
	list.add(new String[] { "3", "jajjaya", "ani", "2435637" });

    }

    @GetMapping(value = "/writecsv")
    public void write() throws IOException {
	File f = new File("D:", "DataFile.csv");
	if (!f.exists())
	    f.createNewFile();

	createData();

	PrintWriter writer = new PrintWriter(f);
	CSVPrinter printer = CSVFormat.DEFAULT.withHeader("ID", "Name", "Request", "Mobile number").print(writer);
	for (String[] segment : list) {
	    printer.printRecord(segment);
	}
	printer.flush();
    }

    @GetMapping(value = "/readfile")
    public List<List<String>> callReader(@RequestParam String data) throws IOException, CsvValidationException {
	List<List<String>> records = new ArrayList<List<String>>(); // D:\\DataFile.csv
	try (CSVReader csvReader = new CSVReader(new FileReader("D:\\DataFile.csv"));) {
	    String[] values = null;
	    boolean flag = false;
	    while ((values = csvReader.readNext()) != null) {
		records.add(Arrays.asList(values));
		// System.out.println(values[0] + " " + values[1] + " " + values[2]);
		if (data.equals(values[4])) {
		    System.out.println(data + " is present");
		    flag = true;
		    break;
		}
	    }
	    if (!flag)
		System.out.println(data + " is not present");
	}
	return records;
    }
}
