package com.opencsvproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OpencsvprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(OpencsvprojectApplication.class, args);
	}

}
